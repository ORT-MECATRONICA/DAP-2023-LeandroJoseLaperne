package com.example.proyectofinal.Fragments

import androidx.lifecycle.ViewModel

class VerMasPaisViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}