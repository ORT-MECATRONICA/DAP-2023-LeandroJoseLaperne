package com.example.proyectofinal.Fragments

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectofinal.Activities.MapaActivity
import com.example.proyectofinal.MainActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import com.example.proyectofinal.R
import com.example.proyectofinal.ViewModelsFragments.myAdapter
import com.example.proyectofinal.item
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*

class TwoFragment : Fragment() {
    private val db = Firebase.firestore

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: myAdapter
    private lateinit var itemArrayList: ArrayList<item>
    private lateinit var searchView: SearchView
    private var distancia: String = "ffgn"
    private var precio: String = "ffgn"
    private var horario: String = "ffgn"
    private var producto: String = "ffgn"
    private var idPubliVendedor: String = "ffgn"


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        postponeEnterTransition()
        return inflater.inflate(R.layout.fragment_two, container, false)
    }

    private lateinit var myActivity: MapaActivity

    override fun onAttach(context: Context) {
        super.onAttach(context)
        myActivity = context as MapaActivity
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if(activity != null && isAdded) {

                val idUsuarioActual = Firebase.auth.currentUser?.uid
                Log.e("TwoFragment", "aaaaa")

                // Initialize RecyclerView, LayoutManager, and Adapter
                recyclerView = view.findViewById(R.id.recyclerView)
                recyclerView.layoutManager = LinearLayoutManager(requireContext())

                // Initialize your itemArrayList with data from Firebase or elsewhere
                itemArrayList = ArrayList()

                // Add your items to itemArrayList as needed
                // For example:
                db.collection("publicaciones")
                    .get()
                    .addOnSuccessListener { publicaciones ->
                        Log.e("TwoFragment", "entro")

//                itemArrayList.clear()

                        for (publicacion in publicaciones) {
                            if (publicacion.get("Reservado") as String == "No") {

                                var newItem = item()
                                val precio = publicacion.get("Precio") as String
                                val horario =
                                    publicacion.get("Horario De Retiro") as? String
                                        ?: "Retiro 20:00"
                                val producto = publicacion.get("Producto") as String
                                val caducidad = publicacion.get("Fecha Maxima Consumo") as String
                                val idPubliVendedor = publicacion.get("Id vendedor") as String
                                // Realiza acciones basadas en el botón pulsado y los datos de la tarjeta
                                // Por ejemplo, imprimir el producto de la tarjeta
                                println("Button Clicked: Product: $idPubliVendedor")

                                newItem.precio = precio
                                newItem.horario = horario
                                newItem.producto = producto
                                newItem.id = idUsuarioActual
                                newItem.caducidad = caducidad

                                db.collection("vendedores")
                                    .get()
                                    .addOnSuccessListener { vendis ->
                                        for (vendedores in vendis) {
                                            val idVendedor = vendedores.id

                                            if (idVendedor == idPubliVendedor) {

                                                val local = vendedores.get("Negocio") as String
                                                val direccion =
                                                    vendedores.get("Direccion") as String
                                                // Create a new instance of item and set the "local" attribute
                                                newItem.local = local
                                                newItem.direccion = direccion

                                                db.collection("users")
                                                    .get()
                                                    .addOnSuccessListener { users ->
                                                        for (usuarios in users) {
                                                            val idUsuario = usuarios.id
                                                            if (idUsuario == idUsuarioActual) {

                                                                val distanciasMap =
                                                                    usuarios.get("Distancias") as Map<String, String>
                                                                for ((clave, valor) in distanciasMap) {
                                                                    if (clave == idVendedor) {

                                                                        distancia = valor

                                                                        newItem.distancia =
                                                                            distancia

                                                                        break // Terminar el bucle una vez que se encuentre la clave
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        itemArrayList.add(newItem)

                                                        // Create the adapter and set it on the RecyclerView
                                                        adapter =
                                                            myAdapter(
                                                                requireContext(),
                                                                itemArrayList
                                                            )
                                                        recyclerView.adapter = adapter
                                                    }
                                            }
                                        }
                                    }

                                // Initialize SearchView
                                searchView = view.findViewById(R.id.idSV)
                                searchView.setOnQueryTextListener(object :
                                    SearchView.OnQueryTextListener {
                                    override fun onQueryTextSubmit(query: String?): Boolean {
                                        // Handle query submission if needed
                                        return false
                                    }

                                    override fun onQueryTextChange(newText: String?): Boolean {
                                        // Filter the adapter when text changes
                                        adapter.filter.filter(newText)
                                        return true
                                    }
                                })
                            }
                        }
                    }

        }

        startPostponedEnterTransition()
    }
}

