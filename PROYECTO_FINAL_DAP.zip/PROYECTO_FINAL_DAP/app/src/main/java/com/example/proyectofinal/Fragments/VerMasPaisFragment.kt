package com.example.proyectofinal.Fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.proyectofinal.R
import com.example.proyectofinal.ViewModelsFragments.myAdapter
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


lateinit var botonBack: Button
lateinit var pais: TextView
lateinit var capital : TextView
lateinit var continente: TextView
lateinit var descripcion : TextView
lateinit var imageView : ImageView


class VerMasPaisFragment : Fragment() {
    private val db = Firebase.firestore

    companion object {
        fun newInstance() = VerMasPaisFragment()
    }

    private lateinit var viewModel: VerMasPaisViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_ver_mas_pais, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        botonBack = view.findViewById<Button>(R.id.back2)

        pais = view.findViewById<TextView>(R.id.País2)
        capital = view.findViewById<TextView>(R.id.capital2)
        continente = view.findViewById<TextView>(R.id.continente2)
        descripcion = view.findViewById<TextView>(R.id.descripcion2)
        imageView = view.findViewById<ImageView>(R.id.imageView3)

        db.collection("paises")
            .get()
            .addOnSuccessListener { users ->
                for (usuarios in users) {
                    if (usuarios.get("Ver Mas") == "Si") {
                        val capitalText = "Capital: " + usuarios.get("Capital") as? String
                        val continenteText = "Continente: " + usuarios.get("Continente") as? String
                        val descripcionText = "Gerundio: " + usuarios.get("Descripcion") as? String
                        val paisText = "Pais: " + usuarios.get("Pais") as? String
                        val urlImagen = usuarios.getString("Url Bandera")


                        // Asegúrate de que los valores no sean nulos antes de establecer los textos
                        capitalText?.let { capital.setText(it) }
                        continenteText?.let { continente.setText(it) }
                        descripcionText?.let { descripcion.setText(it) }
                        paisText?.let { pais.setText(it) }

                        urlImagen?.let {
                            Glide.with(requireContext())
                                .load(it)
                                .into(imageView)
                        }
                        // Actualizar el campo "Ver Mas" a "No" en Firestore
                        usuarios.reference.update("Ver Mas", "No")
                            .addOnSuccessListener {
                                Log.d("MiApp", "Campo 'Ver Mas' actualizado a 'No'")
                            }
                            .addOnFailureListener { e ->
                                Log.e("MiApp", "Error actualizando campo 'Ver Mas'", e)
                            }

                    }
                }
            }
            .addOnFailureListener { exception ->
                Log.e("MiApp", "Error obteniendo datos: ", exception)
            }



       botonBack.setOnClickListener {

            findNavController().navigate(R.id.vendedorMisPedidos)

        }

        }
}