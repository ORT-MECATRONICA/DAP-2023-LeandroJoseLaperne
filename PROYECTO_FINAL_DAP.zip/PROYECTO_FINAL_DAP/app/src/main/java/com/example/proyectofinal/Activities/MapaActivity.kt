package com.example.proyectofinal.Activities

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.proyectofinal.R
import com.example.proyectofinal.Fragments.MapaFragment
import com.example.proyectofinal.Fragments.ThreeFragment
import com.example.proyectofinal.Fragments.TwoFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MapaActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView

    private val oneFragment = MapaFragment()
    private val twoFragment = TwoFragment()
    private val threeFragment = ThreeFragment()

    // Duration to freeze Bottom Navigation Bar in milliseconds
    private val freezeDuration = 1500L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mapa)

        bottomNav = findViewById(R.id.bottomNav)

        bottomNav.setOnNavigationItemSelectedListener { menuItem ->
            // Disable Bottom Navigation Bar
            disableBottomNav()

            // Process the selected menu item
            when (menuItem.itemId) {
                R.id.one -> replaceFragment(oneFragment)
                R.id.two -> replaceFragment(twoFragment)
                R.id.three -> replaceFragment(threeFragment)
            }

            // Delay to freeze Bottom Navigation Bar for a certain duration
            Handler(Looper.getMainLooper()).postDelayed({
                // Enable Bottom Navigation Bar after the delay
                enableBottomNav()
            }, freezeDuration)

            true
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        if (fragment != null) {
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragmentContainerView3, fragment)
            transaction.commit()
        }
    }

    private fun disableBottomNav() {
        bottomNav.menu.setGroupEnabled(0, false) // Disable all items in the first group
    }

    private fun enableBottomNav() {
        bottomNav.menu.setGroupEnabled(0, true) // Enable all items in the first group
    }
}
