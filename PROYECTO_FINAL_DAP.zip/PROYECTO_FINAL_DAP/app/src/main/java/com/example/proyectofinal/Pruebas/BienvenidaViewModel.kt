package com.example.proyectofinal.Pruebas

import androidx.lifecycle.ViewModel

class BienvenidaViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}