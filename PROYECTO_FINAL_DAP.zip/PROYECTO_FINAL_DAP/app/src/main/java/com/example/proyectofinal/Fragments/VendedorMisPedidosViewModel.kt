package com.example.proyectofinal.Fragments

import androidx.lifecycle.ViewModel

class VendedorMisPedidosViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}