package com.example.proyectofinal.Fragments

import androidx.lifecycle.ViewModel

class CrearPublicaiconViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}