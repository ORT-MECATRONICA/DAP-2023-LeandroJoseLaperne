package com.example.proyectofinal.ViewModelsFragments

import androidx.lifecycle.ViewModel

class VendedorRegisterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}